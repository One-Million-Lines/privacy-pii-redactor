# Privacy-First PII Redactor

> A self-hosted Python proxy that detects and removes sensitive data before prompts reach external AI providers.

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![CI](https://github.com/your-org/privacy-pii-redactor/actions/workflows/ci.yml/badge.svg)](https://github.com/your-org/privacy-pii-redactor/actions)

**Privacy-First PII Redactor** helps teams use external LLMs without sending raw names, email addresses, phone numbers, payment details, and other sensitive information. It runs inside your infrastructure, replaces detected data with temporary placeholders, and can optionally restore the values after the LLM responds.

---

## Architecture

```
┌──────────────────────┐
│  Client Application  │
└──────────┬───────────┘
           │
           ▼
┌──────────────────────────────────────┐
│  Privacy PII Redactor                │
│                                      │
│  ┌───────────────────────────────┐   │
│  │  Detection Engine             │   │
│  │  Regex + Presidio + spaCy     │   │
│  └──────────────┬────────────────┘   │
│                 │                    │
│  ┌──────────────▼────────────────┐   │
│  │  Redaction Engine             │   │
│  │  Placeholder Manager          │   │
│  └──────────────┬────────────────┘   │
│                 │                    │
│  ┌──────────────▼────────────────┐   │
│  │  Mapping Store                │   │
│  │  Redis / In-Memory            │   │
│  └───────────────────────────────┘   │
│                                      │
│  ┌───────────────────────────────┐   │
│  │  Optional LLM Proxy           │   │
│  └──────────────┬────────────────┘   │
└─────────────────┼────────────────────┘
                  │
                  ▼
        External LLM Provider
```

---

## Quick Start

### Install

```bash
pip install privacy-pii-redactor
```

### Python Library

```python
from pii_redactor import PrivacyRedactor

redactor = PrivacyRedactor()

result = redactor.redact("Contact John at john@example.com, card 4111 1111 1111 1111")
print(result.redacted_text)
# → "Contact <PERSON_1> at <EMAIL_1>, card <CREDIT_CARD_1>"

# Restore original values
restored = redactor.restore(result.redacted_text, result.mapping)
print(restored.restored_text)
# → "Contact John at john@example.com, card 4111 1111 1111 1111"
```

### CLI

```bash
# Redact a string
pii-redactor redact "Email me at alice@example.com"

# Redact a file
pii-redactor redact-file input.txt --output sanitized.txt

# Detect PII (no redaction)
pii-redactor detect report.txt --json

# Start the API server
pii-redactor serve
```

### REST API

```bash
docker compose up
```

```bash
# Detect PII
curl -X POST http://localhost:8000/v1/detect \
  -H "Content-Type: application/json" \
  -d '{"text": "Email john@example.com"}'

# Redact PII
curl -X POST http://localhost:8000/v1/redact \
  -H "Content-Type: application/json" \
  -d '{"text": "Email john@example.com", "store_mapping": true}'

# Restore (using mapping_id from redact response)
curl -X POST http://localhost:8000/v1/restore \
  -H "Content-Type: application/json" \
  -d '{"text": "<EMAIL_1>", "mapping_id": "..."}'
```

---

## Features

- **Multiple detection layers**: Microsoft Presidio, spaCy NER, and deterministic regex patterns
- **15+ PII types**: emails, phones, credit cards, IBANs, SSNs, IPs, URLs, addresses, dates, passports, and more
- **Deduplication**: the same original value always gets the same placeholder within one request
- **Conflict resolution**: overlapping detections from different sources are resolved by priority (regex > Presidio > spaCy)
- **Reversible redaction**: store a temporary mapping in Redis and restore original values after the LLM responds
- **Custom recognizers**: define your own regex patterns via Python or YAML
- **REST API**: FastAPI-powered with OpenAPI docs at `/docs`
- **CLI**: `pii-redactor` command for scripting and batch processing
- **LLM Proxy**: transparent OpenAI-compatible proxy endpoint
- **Docker-ready**: single `docker compose up` deployment
- **Security-first**: API key auth, constant-time comparison, TTL-based mapping expiry, safe logging

---

## Supported PII Types

| Type | Examples | Method |
|------|----------|--------|
| Email | `alice@example.com` | Regex |
| Phone | `+1-555-123-4567`, `(555) 123-4567` | Regex |
| Credit Card | Visa, MC, Amex (Luhn-validated) | Regex |
| IBAN | `DE89 3704 0044 0532 0130 00` | Regex |
| IP Address | IPv4 and IPv6 | Regex |
| URL | `https://example.com/path` | Regex |
| SSN (US) | `123-45-6789` | Regex |
| Date of Birth | `1990-01-15`, `January 15, 1990` | Regex |
| Passport | `AB1234567` | Regex |
| Physical Address | `123 Main Street` | Regex |
| ZIP / Postal Code | US, UK, Canadian | Regex |
| Person Name | John Smith | Presidio / spaCy |
| Organization | Acme Corp | Presidio / spaCy |
| Location | New York City | Presidio / spaCy |
| Custom | Define your own | YAML / Python |

---

## Configuration

All settings can be provided via environment variables or a `.env` file.

```env
# Application
APP_ENV=production
HOST=0.0.0.0
PORT=8000

# Storage
REDIS_URL=redis://localhost:6379/0
MAPPING_TTL_SECONDS=900        # 15 minutes

# Detection
DEFAULT_LANGUAGE=en
MIN_CONFIDENCE_SCORE=0.65
ENABLE_SPACY=true
ENABLE_PRESIDIO=true
ENABLE_REGEX=true

# Security
API_KEY=                       # Leave empty to disable authentication

# Logging
LOG_LEVEL=INFO

# LLM Proxy (optional)
LLM_PROVIDER_URL=
LLM_PROVIDER_API_KEY=
LLM_TIMEOUT_SECONDS=60
```

### YAML Config (optional)

```yaml
# config.yaml
entity_overrides:
  PERSON:
    min_confidence: 0.80

custom_recognizers:
  - name: CUSTOMER_ID
    pattern: "\\bCUS-[0-9]{6}\\b"
    confidence: 0.95
  - name: PROJECT_CODE
    pattern: "\\bPRJ-[A-Z]{3}-[0-9]{4}\\b"
    confidence: 0.90
```

Set `CONFIG_FILE=/path/to/config.yaml` to enable it.

---

## API Reference

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/health` | Liveness probe |
| `POST` | `/v1/detect` | Detect PII entities |
| `POST` | `/v1/redact` | Redact PII and optionally store mapping |
| `POST` | `/v1/restore` | Restore original values from stored mapping |
| `POST` | `/v1/chat/completions` | LLM proxy with transparent redaction |

Full interactive docs at `http://localhost:8000/docs`.

---

## Authentication

When `API_KEY` is set, the `/v1/restore` and `/v1/chat/completions` endpoints require:

```http
Authorization: Bearer your-api-key-here
```

The key is compared using constant-time comparison to prevent timing attacks.

---

## Privacy Modes

### 1. Redact Only (maximum privacy)
```python
result = redactor.redact(text, store_mapping=False)
# No mapping stored — one-way operation
```

### 2. Reversible Redaction
```python
result = redactor.redact(text, store_mapping=True)
# Returns result.mapping_id for later restoration
```

### 3. LLM Proxy Mode
```http
POST /v1/chat/completions
{"restore_response": true}
```
Redacts, forwards to LLM, and restores the response automatically.

---

## Docker Deployment

```bash
git clone https://github.com/your-org/privacy-pii-redactor
cd privacy-pii-redactor
cp .env.example .env
docker compose up --build
```

The API will be available at `http://localhost:8000`.

---

## Development

```bash
git clone https://github.com/your-org/privacy-pii-redactor
cd privacy-pii-redactor
pip install -e ".[dev]"
pytest tests/ -v
```

---

## Important Limitations

> **Please read before using in production.**

- PII detection is probabilistic and **may produce false positives or false negatives**.
- Person names and physical addresses are **harder to detect reliably** than emails or credit cards.
- The system **reduces privacy risk** but does not guarantee regulatory compliance (GDPR, HIPAA, etc.).
- You must evaluate this tool against your own legal, security, and compliance requirements.
- Restoring values into an LLM response can produce **incorrect results** when the LLM modifies placeholders.
- **Do not use this as the only security layer.** Apply defence-in-depth.
- Sensitive documents must still follow normal access-control and data-retention policies.

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).

## Security

See [SECURITY.md](SECURITY.md) for reporting vulnerabilities.

## License

MIT — see [LICENSE](LICENSE).
